========onion98========
==a theme for onionOS==

This theme is a heavily modified version of the win98 theme by kyhynngy_oyuur, which can be downloaded from the OnionUI themes repository(https://github.com/OnionUI/Themes?tab=readme-ov-file).

The theme includes the W95FA font which is licensed under the SIL Open Font License.

All Windows icons were taken from the Windows 98 Icon Viewer(https://win98icons.alexmeub.com/) and old windows icons(https://oldwindowsicons.tumblr.com/) on tumblr. 

Feel free to use or edit this theme in any way you wish.  Go hog wild my friend.